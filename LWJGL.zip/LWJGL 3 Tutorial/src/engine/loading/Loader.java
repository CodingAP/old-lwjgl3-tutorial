package engine.loading;
 
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.newdawn.slick.opengl.TextureLoader;

import engine.rendering.Material;
import engine.rendering.models.TexturedModel;
import engine.rendering.models.UntexturedModel;
 
public class Loader {
     
    private List<Integer> vertexArrayIDs = new ArrayList<Integer>();
    private List<Integer> vertexBufferIDs = new ArrayList<Integer>();
    private List<Integer> textureIDs = new ArrayList<Integer>();
     
    public UntexturedModel loadModel(float[] positions, int[] indices) {
        int vertexArrayID = createVertexArray();
        bindIndicesBuffer(indices);
        storeData(0, 3, positions);
        GL30.glBindVertexArray(0);
        return new UntexturedModel(vertexArrayID, indices.length);
    }
    
    public TexturedModel loadTexturedModel(float[] positions, float[] textureCoords, int[] indices, String file) {
        int vertexArrayID = createVertexArray();
        bindIndicesBuffer(indices);
        storeData(0, 3, positions);
        storeData(1, 2, textureCoords);
        GL30.glBindVertexArray(0);
        return new TexturedModel(new UntexturedModel(vertexArrayID, indices.length), new Material(loadTexture(file)));
    }
    
    public int loadTexture(String file) {
    	int textureID = 0;
    	try {
			textureID = TextureLoader.getTexture("png", new FileInputStream("res/textures/" + file)).getTextureID();
		} catch (IOException e) {
			System.err.println("Error: Couldn't load texture");
			System.exit(-1);
		}
    	textureIDs.add(textureID);
    	return textureID;
    }
     
    public void remove() {
        for(int vertexArrayID : vertexArrayIDs){
            GL30.glDeleteVertexArrays(vertexArrayID);
        }
        
        for(int vertexBufferID : vertexBufferIDs){
            GL15.glDeleteBuffers(vertexBufferID);
        }
        
        for(int textureID : textureIDs){
            GL15.glDeleteBuffers(textureID);
        }
    }
     
    private int createVertexArray() {
        int vertexArrayID = GL30.glGenVertexArrays();
        vertexArrayIDs.add(vertexArrayID);
        GL30.glBindVertexArray(vertexArrayID);
        return vertexArrayID;
    }
     
    private void storeData(int attributeNumber, int coordSize, float[] data) {
    	FloatBuffer buffer = BufferUtils.createFloatBuffer(data.length);
        buffer.put(data);
        buffer.flip();
        int vertexBufferID = GL15.glGenBuffers();
        vertexBufferIDs.add(vertexBufferID);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vertexBufferID);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
        GL20.glVertexAttribPointer(attributeNumber, coordSize, GL11.GL_FLOAT, false, 0, 0);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
    }
     
    private void bindIndicesBuffer(int[] indices) {
    	IntBuffer buffer = BufferUtils.createIntBuffer(indices.length);
        buffer.put(indices);
        buffer.flip();
        int vertexBufferID = GL15.glGenBuffers();
        vertexBufferIDs.add(vertexBufferID);
        GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, vertexBufferID);
        GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
    }
}
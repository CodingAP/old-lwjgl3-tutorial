package engine.rendering;

public class Material {
	private int textureID;
	
	public Material(int id) {
		textureID = id;
	}

	public int getTextureID() {
		return textureID;
	}
}

package engine.rendering.models;

import engine.rendering.Material;

public class TexturedModel {
	private UntexturedModel model;
	private Material material;
	
	public TexturedModel(UntexturedModel model, Material material) {
		this.model = model;
		this.material = material;
	}
	
	public UntexturedModel getModel() {
		return model;
	}
	
	public Material getMaterial() {
		return material;
	}
}
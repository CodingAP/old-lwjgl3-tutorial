package engine.rendering.models;
 
public class UntexturedModel {
    private int vertexArrayID;
    private int vertexCount;
    
    public UntexturedModel(int vaoID, int vertexCount){
        this.vertexArrayID = vaoID;
        this.vertexCount = vertexCount;
    }
 
    public int getVertexArrayID() {
        return vertexArrayID;
    }
 
    public int getVertexCount() {
        return vertexCount;
    }
}
package engine.shaders;
 
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
 
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
 
public abstract class Shader {
    private int programID;
    private int vertexShaderID;
    private int fragmentShaderID;
     
    public Shader(String vertexFile, String fragmentFile){
        vertexShaderID = loadShader(vertexFile, GL20.GL_VERTEX_SHADER);
        fragmentShaderID = loadShader(fragmentFile, GL20.GL_FRAGMENT_SHADER);
        programID = GL20.glCreateProgram();
        GL20.glAttachShader(programID, vertexShaderID);
        GL20.glAttachShader(programID, fragmentShaderID);
        bindAttributes();
        GL20.glLinkProgram(programID);
        if (GL20.glGetProgrami(programID, GL20.GL_LINK_STATUS) == GL11.GL_FALSE){
            System.err.println("Error: Program Linking - " + GL20.glGetShaderInfoLog(programID));
            System.exit(-1);
        }
        
        GL20.glValidateProgram(programID);
        if (GL20.glGetProgrami(programID, GL20.GL_VALIDATE_STATUS) == GL11.GL_FALSE){
            System.err.println("Error: Program Validating - " + GL20.glGetShaderInfoLog(programID));
            System.exit(-1);
        }
    }
     
    public void bind() {
        GL20.glUseProgram(programID);
    }
     
    public void unbind() {
        GL20.glUseProgram(0);
    }
     
    public void remove() {
    	unbind();
        GL20.glDetachShader(programID, vertexShaderID);
        GL20.glDetachShader(programID, fragmentShaderID);
        GL20.glDeleteShader(vertexShaderID);
        GL20.glDeleteShader(fragmentShaderID);
        GL20.glDeleteProgram(programID);
    }
     
    protected abstract void bindAttributes();
     
    protected void bindAttribute(int attribute, String variableName) {
        GL20.glBindAttribLocation(programID, attribute, variableName);
    }
     
    private static int loadShader(String file, int type) {
        StringBuilder shaderSource = new StringBuilder();
        try{
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while((line = reader.readLine())!=null){
                shaderSource.append(line).append("//\n");
            }
            reader.close();
        } catch(IOException e){
            e.printStackTrace();
            System.exit(-1);
        }
        int shaderID = GL20.glCreateShader(type);
        GL20.glShaderSource(shaderID, shaderSource);
        GL20.glCompileShader(shaderID);
        String shaderName = "";
        if (type == GL20.GL_VERTEX_SHADER) shaderName = "Vertex";
        if (type == GL20.GL_FRAGMENT_SHADER) shaderName = "Fragment";
        if (GL20.glGetShaderi(shaderID, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE){
        	System.err.println("Error: " + shaderName + " Shader - " + GL20.glGetShaderInfoLog(shaderID));
            System.exit(-1);
        }
        return shaderID;
    }
}
package main;

import engine.io.Window;
import engine.loading.Loader;
import engine.rendering.Renderer;
import engine.rendering.models.TexturedModel;
import engine.shaders.BasicShader;
 
public class Main {
 
    public static void main(String[] args) {
    	Window window = new Window(1080, 720, 60, "LWJGL");
    	window.create();
    	window.setBackgroundColor(1.0f, 0.0f, 0.0f);
        Loader loader = new Loader();
        Renderer renderer = new Renderer();
        BasicShader shader = new BasicShader();
         
        TexturedModel model = loader.loadTexturedModel(new float[] {            
                -0.5f,0.5f,0,   //V0
                -0.5f,-0.5f,0,  //V1
                0.5f,-0.5f,0,   //V2
                0.5f,0.5f,0     //V3
        }, new float[] {
        		0, 0,
        		0, 1,
        		1, 1,
        		1, 0
        }, new int[] {
                0,1,3,  //Top left triangle (V0,V1,V3)
                3,1,2   //Bottom right triangle (V3,V1,V2)
        }, "beautiful.png");
         
        while(!window.closed()) {
        	if (window.isUpdating()) {
        		window.update();
	            shader.bind();
	            renderer.renderTexturedModel(model);
	            shader.unbind();
	            window.swapBuffers();
        	}
        }
 
        shader.remove();
        loader.remove();
        window.stop();
    }
}
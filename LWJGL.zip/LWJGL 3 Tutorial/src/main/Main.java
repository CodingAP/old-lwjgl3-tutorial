package main;

import engine.io.Window;
import engine.rendering.Renderer;
import engine.rendering.models.UntexturedModel;
import engine.shaders.BasicShader;
 
public class Main {
	private static final int WIDTH = 800, HEIGHT = 600, FPS = 60;
	private static Window window = new Window(WIDTH, HEIGHT, FPS, "LWJGL");
	private static Renderer renderer = new Renderer();
	private static BasicShader shader = new BasicShader();
	
    public static void main(String[] args) {
    	window.create();
    	window.setBackgroundColor(1.0f, 0.0f, 0.0f);
        shader.create();
        
        UntexturedModel model = new UntexturedModel(new float[] {
        		-0.5f, 0.5f, 0,  //V0
        		 0.5f, 0.5f, 0,  //V1
        		-0.5f, -0.5f, 0, //V2
        		 0.5f, -0.5f, 0, //V3
        }, new int[] {
        		 0, 1, 2,
        		 1, 3, 2
        });
        
        while (!window.closed()) {
        	if (window.isUpdating()) {
        		window.update();
	            shader.bind();
	            renderer.renderModel(model);
	            window.swapBuffers();
        	}
        }
 
        model.remove();
        shader.remove();
        window.stop();
    }
}
package engine.shaders;
 
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
 
public abstract class Shader {
    private int programID, vertexShaderID, fragmentShaderID;
    private String vertexFile, fragmentFile;
     
    public Shader(String vertexFile, String fragmentFile){
        this.vertexFile = vertexFile;
        this.fragmentFile = fragmentFile;
    }
    
    public void create() {
    	vertexShaderID = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
    	GL20.glShaderSource(vertexShaderID, readFile(vertexFile));
    	GL20.glCompileShader(vertexShaderID);
    	if (GL20.glGetShaderi(vertexShaderID, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE){
            System.err.println("Error: Vertex Shader - " + GL20.glGetShaderInfoLog(vertexShaderID));
            System.exit(-1);
        }
    	
    	fragmentShaderID = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
    	GL20.glShaderSource(fragmentShaderID, readFile(fragmentFile));
    	GL20.glCompileShader(fragmentShaderID);
    	if (GL20.glGetShaderi(fragmentShaderID, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE){
            System.err.println("Error: Fragment Shader - " + GL20.glGetShaderInfoLog(fragmentShaderID));
            System.exit(-1);
        }
    	
        programID = GL20.glCreateProgram();
        
        GL20.glAttachShader(programID, vertexShaderID);
        GL20.glAttachShader(programID, fragmentShaderID);
        
        bindAttributes();
        
        GL20.glLinkProgram(programID);
        if (GL20.glGetProgrami(programID, GL20.GL_LINK_STATUS) == GL11.GL_FALSE){
            System.err.println("Error: Program Linking - " + GL20.glGetProgramInfoLog(programID));
            System.exit(-1);
        }
        
        GL20.glValidateProgram(programID);
        if (GL20.glGetProgrami(programID, GL20.GL_VALIDATE_STATUS) == GL11.GL_FALSE){
            System.err.println("Error: Program Validating - " + GL20.glGetProgramInfoLog(programID));
            System.exit(-1);
        }
    }
     
    public void bind() {
        GL20.glUseProgram(programID);
    }
     
    public void remove() {
    	GL20.glUseProgram(0);
        GL20.glDetachShader(programID, vertexShaderID);
        GL20.glDetachShader(programID, fragmentShaderID);
        GL20.glDeleteShader(vertexShaderID);
        GL20.glDeleteShader(fragmentShaderID);
        GL20.glDeleteProgram(programID);
    }
     
    protected abstract void bindAttributes();
     
    protected void bindAttribute(int attribute, String variableName) {
        GL20.glBindAttribLocation(programID, attribute, variableName);
    }
     
    private String readFile(String file) {
        StringBuilder string = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null){
            	string.append(line).append("\n");
            }
            reader.close();
        } catch (IOException e) {
            System.err.println("Error: Couldn't find file");
            System.exit(-1);
        }
        return string.toString();
    }
}
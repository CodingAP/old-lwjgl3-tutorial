package main;

import engine.io.Window;
import engine.rendering.Renderer;
import engine.rendering.models.TexturedModel;
import engine.shaders.BasicShader;
 
public class Main {
	private static final int WIDTH = 800, HEIGHT = 600, FPS = 60;
	private static Window window = new Window(WIDTH, HEIGHT, FPS, "LWJGL");
	private static Renderer renderer = new Renderer();
	private static BasicShader shader = new BasicShader();
	
    public static void main(String[] args) {
    	window.create();
    	window.setBackgroundColor(1.0f, 0.0f, 0.0f);
        shader.create();
        
        TexturedModel model = new TexturedModel(new float[] {            
                -0.5f, 0.5f, 0,  //V0
                -0.5f, -0.5f, 0, //V1
                 0.5f, -0.5f, 0, //V2
                 0.5f, 0.5f, 0   //V3
        }, new float[] {
        		 0, 0,           //V0
        		 0, 1,           //V1
        		 1, 1,           //V2
        		 1, 0            //V3
        }, new int[] {
                 0, 1, 3,        //Triangle 1
                 3, 1, 2         //Triangle 2
        }, "beautiful.png");
         
        while (!window.closed()) {
        	if (window.isUpdating()) {
        		window.update();
	            shader.bind();
	            renderer.renderTexturedModel(model);
	            window.swapBuffers();
        	}
        }
 
        model.remove();
        shader.remove();
        window.stop();
    }
}